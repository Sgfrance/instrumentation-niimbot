INSTRUMENTATION — PONT WEB NIIMBOT B1 PRO

1) Héberger index.html sur une adresse HTTPS (GitHub Pages, IONOS, serveur web interne HTTPS...).
2) Exemple URL unitaire :
   https://VOTRE-SITE/niimbot/?type=PASSERELLE&model=A-7788&number=04&code=PAS-A7788-04
3) Exemple lot :
   https://VOTRE-SITE/niimbot/?mode=batch&type=PASSERELLE&model=A-7788&prefix=PAS&first=001&last=010&digits=3
4) Ouvrir avec Microsoft Edge ou Google Chrome.
5) Cliquer CONNECTER & IMPRIMER, choisir la B1 Pro au premier appairage.

Le code-barres CODE128 encode exactement le champ code/CodeMateriel.
Géométrie impression : 38 x 25 mm, 449 x 295 px, 300 dpi (B1 Pro).
Le pilote Web Bluetooth utilisé est niimbot-web-bluetooth (MIT) via jsDelivr.
